module Main where
-- import Data.Number.CReal

rotatex alpha x y = x * cos alpha - y * sin alpha 
rotatey alpha x y = x * sin alpha + y * cos alpha 

main = do
    let x = 0
    let y = 1
    let alpha = 90
    let x' = rotatex alpha x y
    let y' = rotatey alpha x y
    print x'
    print y'
